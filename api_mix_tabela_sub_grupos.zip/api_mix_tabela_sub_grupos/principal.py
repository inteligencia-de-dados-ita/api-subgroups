#Busca de Ativos  
#Get /api/assets/group/{groupid}
#Eventos por ativo
import pandas as pd
import mix_api
import db_connection

inte = []

contador = 0

#date = data_from_to.date_ft()

groupid = '-4470520382106153168'

#mix_api.api_request2('/api/organisationgroups/subgroups/',groupid)
db_connection.db()
try:



    
    import json
    with open( "mix_api-_api_organisationgroups_subgroups_.json") as meu_json:
        dados = json.load(meu_json)
        u = len(dados['SubGroups'])
    for i in range(0,u):                                                                                                                                         
        dt0 = pd.DataFrame(dados['SubGroups'][i]['SubGroups'])
        result = dt0.empty
        if (result is False):
         print("--------")
         print(dt0[['GroupId', 'Name']])
         print("--------")
        tam = len(dt0)
        if(tam>1):
         for t in range(0,tam):
            dft= pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t]['SubGroups']) 
            dp = pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t])
            dp = dp.rename(columns={'GroupId': 'Id'})
            result1 = dft.empty
            if(result1 is False):
             tam1 = len(dft)
             #print("***********************")
             db_connection.dbt(dft[['GroupId', 'Name']], dp[['Id']])
             #print("***********************")
                
             if(tam1>1):
                for p in range(0,tam1):
                   dft1 =  pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t]['SubGroups'][p]['SubGroups'])
                   result2 = dft1.empty
                   if(result2 is False):
                      tam2 = len(dft1)
                      #print("==================================")
                      db_connection.dbt(dft1[['GroupId', 'Name']], dp[['Id']])
                      #print("==================================")
                      if(tam2>1):
                         for v in range(0,tam2):
                            dft2 =  pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t]['SubGroups'][p]['SubGroups'][v]['SubGroups']) 
                            result3 = dft2.empty
                            if(result3 is False):
                               da = pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t])
                               da1 = pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t]['SubGroups'][p]) 
                               tam3 = len(dft2)
                               #print("#################")
                               db_connection.dbt(dft2[['GroupId', 'Name']], dp[['Id']])
                               #print("#################")
                               if(tam3>1):
                                  for r in range(0,tam3):
                                     dft3 = pd.DataFrame(dados['SubGroups'][i]['SubGroups'][t]['SubGroups'][p]['SubGroups'][v]['SubGroups'][r]['SubGroups'])
                                     result4 = dft3.empty
                                     if(result4 is False):
                                        print(dft3[['GroupId', 'Name']])


                            

                      

            

except Exception as error:
     print(f"erro: {error}")