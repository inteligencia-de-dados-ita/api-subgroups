import os
import base64
from requests.utils import quote
import requests
import datetime
import random
import uuid 
import json
from time import sleep
dir_path = os.path.dirname(os.path.realpath(__file__))
#if os.path.isdir("json"):
    #print('')
#else:
    #os.mkdir('json')
def api_request2(endpoint:str, ft:str):
    name_api = endpoint.replace("/","_")
    IdentityUrl = "https://identity.us.mixtelematics.com"  
    ApiUrl = "https://integrate.us.mixtelematics.com"
    IdentityClientId = "mixbrita"
    IdentityClientSecret = "TvnzFR5BBl4Z313C"
    IdentityUsername = "telemetria@itafrotas.com"
    IdentityPassword = "tele@metria2022"
    IdentityScope = "offline_access+MiX.Integrate"
    ConfigUrl = IdentityUrl + "/core/.well-known/openid-configuration" 
    ConfigResponse = requests.get(ConfigUrl) 
    IdServerConfig = json.loads(ConfigResponse.content)
    IdTokenEndPoint = IdServerConfig["token_endpoint"]
    auth = "Basic " + base64.b64encode(bytes(IdentityClientId + ":" + IdentityClientSecret, "utf-8")).decode('ascii')
    body = "grant_type=password&username=" + quote(IdentityUsername) + "&password=" + quote(IdentityPassword) + "&scope=" + IdentityScope
    TokenResponse = requests.post(IdTokenEndPoint, data = body, headers = {"accept":"application/json", "Authorization":auth }) 
    Token = json.loads(TokenResponse.content)
    BearerToken = "Bearer " + Token["access_token"]
    #print(BearerToken)
    GetAssetsForGroupUrl = ApiUrl + endpoint + ft
    print("Request: " + GetAssetsForGroupUrl)

    AssetsResponse = requests.get(GetAssetsForGroupUrl, headers = {"accept":"application/json", "Authorization":BearerToken } ,timeout=None)
    print(AssetsResponse.status_code, AssetsResponse.reason)
    Assets = json.loads(AssetsResponse.content)
    
    if(AssetsResponse.status_code == 200):
        agora = datetime.date.today()
        x = random.random()
        x = str(x)
        d1= agora.strftime("%d/%m/%Y")
        t = d1
        hash = uuid.uuid5(uuid.NAMESPACE_URL, x)
        name = f'/mix_api-{name_api}.json'
        print(dir_path)
        print(name)
        with open(dir_path+'/'+name, "w") as file:
            json.dump(Assets, file)
            print('Arquivo gerado com sucesso!')
        return Assets
    
    elif(AssetsResponse.status_code == 204):
        print("aguarde 30 segundos")
        sleep(30)
        
    else:
        print(Assets)
        return Assets
