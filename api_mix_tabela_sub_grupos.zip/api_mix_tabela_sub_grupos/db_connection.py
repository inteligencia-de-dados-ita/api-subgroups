from datetime import datetime

def db():

    import pyodbc
    now = datetime.now()

    server = '192.168.1.182'

    database = 'api_mix'

    username = 'sa'

    password = 'Gustavo@123'

    cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cursor = cnxn.cursor()

    print(f'Conexao bem sucedida criar: {now}')
    
    criar =  '''USE api_mix
        IF OBJECT_ID('subgroupid', 'U') IS NOT NULL
        BEGIN
        drop table subgroupid
                CREATE TABLE subgroupid(
                    Id VARCHAR(255) NOT NULL, 
                    Name VARCHAR(255) NOT NULL,
                    GroupId VARCHAR(255) NOT NULL
                    )
        END
        ELSE
        BEGIN
        CREATE TABLE subgroupid(
                    Id VARCHAR(255) NOT NULL, 
                    Name VARCHAR(255) NOT NULL,
                    GroupId VARCHAR(255) NOT NULL
                    )
        END'''
    
    cursor.execute(criar)
    
    print(f"Executando commit: {now}")
    
    cursor.commit()

    print(f"Commit realizado com sucesso:{now}")

   

    cursor.close()

    print(f"Cursor finalizado criar: {now}")
 

def dbt(dt, du):
    import pyodbc
    now = datetime.now()

    server = '192.168.1.182'

    database = 'api_mix'

    username = 'sa'

    password = 'Gustavo@123'

    cnxn = pyodbc.connect('DRIVER={SQL Server};SERVER='+server+';DATABASE='+database+';UID='+username+';PWD='+ password)
    cursor = cnxn.cursor()
    print(f'Conexao bem sucedida inserir: {now}')
    #print(dt[['AssetId','SiteId']])
    inserir = '''
    INSERT INTO subgroupid(
                    Id,
                    Name,
                    GroupId
                    
                    )
        VALUES(?,?,?)'''
    for index, row in dt.iterrows():
        row1=row['GroupId']
        row2=row['Name']
        for index, row in du.iterrows():
            row3= row['Id']
        print(row1, row2, row3)
        cursor.execute(inserir, str(row1), str(row2), str(row3))
        

    
    print(f"Executando commit: {now}")

    cursor.commit()

    print(f"Commit realizado com sucesso:{now}")
    
    cursor.close()

    print(f"Cursor finalizado inserir: {now}")
